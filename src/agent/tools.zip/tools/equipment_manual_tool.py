"""
equipment_manual_tool.py — RAG search scoped to equipment manuals.

Uses the match_document_chunks RPC with doc_ids filter to search only
in documents linked to the equipment via lab.equipment_documents.

Includes query expansion for cross-language support (Spanish → English).
"""

import logging
from typing import List, Optional
from langchain_core.tools import tool
from langchain_core.documents import Document

logger = logging.getLogger("equipment_manual_tool")

# Mapeo de términos comunes ES → EN para expandir queries cross-language
_TERM_MAP = {
    "diagnóstico": "diagnostic troubleshooting",
    "diagnostico": "diagnostic troubleshooting",
    "comunicación": "communication PROFINET",
    "comunicacion": "communication PROFINET",
    "error": "error fault code",
    "conexión": "connection online going-online",
    "conexion": "connection online going-online",
    "descargar": "download upload",
    "subir código": "download upload program",
    "subir codigo": "download upload program",
    "cargar": "download upload load program",
    "código": "program code",
    "codigo": "program code",
    "estado": "status state LED indicator",
    "configuración": "configuration setup parameters",
    "configuracion": "configuration setup parameters",
    "red": "network Ethernet PROFINET IP",
    "puerta": "door safety interlock",
    "cobot": "robot cobot collaborative",
    "sensor": "sensor input signal",
    "motor": "motor drive actuator",
    "parada": "stop emergency halt",
    "arranque": "start startup power-on",
    "memoria": "memory load capacity",
    "firmware": "firmware update version",
    "módulo": "module expansion",
    "modulo": "module expansion",
    "alimentación": "power supply voltage",
    "alimentacion": "power supply voltage",
    "dirección ip": "IP address assignment",
    "direccion ip": "IP address assignment",
}


def _expand_query(query: str) -> str:
    """Expande una query con términos en inglés para mejor matching cross-language."""
    query_lower = query.lower()
    expansions = []
    for es_term, en_terms in _TERM_MAP.items():
        if es_term in query_lower:
            expansions.append(en_terms)
    if expansions:
        expanded = f"{query} {' '.join(expansions)}"
        logger.info(f"Query expanded: '{query}' → '{expanded[:120]}...'")
        return expanded
    return query


def make_equipment_manual_tool(supabase_client, embeddings_model, equipment_id: str, doc_ids: List[str]):
    """
    Factory that creates a search tool scoped to an equipment's manuals.

    Args:
        supabase_client: Supabase client instance
        embeddings_model: Embeddings model for generating query vectors
        equipment_id: UUID of the equipment profile
        doc_ids: List of document IDs linked to this equipment

    Returns:
        LangChain tool that searches only in this equipment's manuals
    """

    if not doc_ids:
        @tool
        def search_equipment_manual(query: str) -> str:
            """Search equipment manual for troubleshooting information. No manuals are linked to this equipment."""
            return "No manuals linked to this equipment. Provide general troubleshooting guidance."
        return search_equipment_manual

    @tool
    def search_equipment_manual(query: str, num_results: int = 5) -> str:
        """Search the equipment's technical manual for troubleshooting information.

        Use this to find specific error codes, diagnostic procedures, wiring diagrams,
        configuration steps, and troubleshooting guides from the official manual.

        IMPORTANT: Queries should be in English (manuals are in English).

        Args:
            query: What to search for in English (e.g. "communication error LED indicators", "download program CPU")
            num_results: Number of results to return (default 5)
        """
        try:
            # Expandir query con términos en inglés si contiene español
            expanded_query = _expand_query(query)

            # Generar embedding de la query expandida
            query_embedding = embeddings_model.embed_query(expanded_query)

            # Buscar con más resultados para compensar threshold
            result = supabase_client.rpc("match_document_chunks", {
                "query_embedding": query_embedding,
                "match_count": num_results + 3,  # Pedir extras para compensar filtering
                "doc_ids": doc_ids,
            }).execute()

            if not result.data:
                return f"No relevant sections found in the manual for: '{query}'"

            # Formatear resultados — threshold bajo para cross-language
            sections = []
            for chunk in result.data:
                similarity = chunk.get("similarity", 0)
                if similarity < 0.15:  # Threshold bajo para cross-language queries
                    continue

                title = chunk.get("doc_title", "Manual")
                page_start = chunk.get("page_start", "?")
                page_end = chunk.get("page_end", "?")
                content = chunk.get("content", "")

                if len(content) > 1500:
                    content = content[:1500] + "..."

                page_ref = f"p.{page_start}" if page_start == page_end else f"pp.{page_start}-{page_end}"
                sections.append(
                    f"### {title} ({page_ref}) [relevance: {similarity:.2f}]\n{content}"
                )

                if len(sections) >= num_results:
                    break

            if not sections:
                return (f"No relevant sections found for: '{query}'. "
                        "Try searching with different English keywords.")

            logger.info(f"Manual search: query='{query}', results={len(sections)}")
            return "\n\n---\n\n".join(sections)

        except Exception as e:
            return f"Error searching manual: {str(e)}"

    return search_equipment_manual
