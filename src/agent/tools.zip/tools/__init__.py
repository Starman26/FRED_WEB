"""
Tools del sistema multi-agente ATLAS

Módulos:
- robot_tools/: Control del robot xArm
- rag_tools: Búsqueda RAG en documentos
"""
from .rag_tools import make_retrieve_tool, make_web_search_tool

# Robot tools
try:
    from .robot_tools import XARM_TOOLS, ROBOT_TOOLS_AVAILABLE
except ImportError:
    XARM_TOOLS = []
    ROBOT_TOOLS_AVAILABLE = False


__all__ = [
    "make_retrieve_tool",
    "make_web_search_tool",
    "XARM_TOOLS",
    "ROBOT_TOOLS_AVAILABLE",
]
